import React from 'react'

const About = () => {
  return (
    <div>
        About page on Get me a Chai using Tailwind CSS and NEXT.js
      <h1 className='text-xl'>About</h1>
    </div>
  )
}

export default About

export const metadata = {
  title: 'About - Get Me A Chai',
}
