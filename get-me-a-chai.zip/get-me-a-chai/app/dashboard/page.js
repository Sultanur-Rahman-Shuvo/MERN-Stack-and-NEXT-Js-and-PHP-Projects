"use client";
import React from 'react';
import Head from 'next/head';
import Dashboard from '@/components/Dashboard';

const DashboardPage = () => {
  return (
    <div>
      <Head>
        <title>Dashboard - Get Me A Chai</title>
      </Head>
      <Dashboard />
    </div>
  );
}

export default DashboardPage;